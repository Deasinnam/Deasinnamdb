@echo off
chcp 65001 >nul
title 덜누름 로컬 AI 설치
echo 덜누름 로컬 AI 설치를 시작합니다...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
