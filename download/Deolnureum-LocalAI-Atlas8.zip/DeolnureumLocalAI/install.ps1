﻿# ============================================================
#  덜누름 로컬 AI 설치 스크립트 (에이서 프레데터 아틀라스 8 최적화)
#  대상: 에이서 프레데터 아틀라스 8 (Intel Arc G3 Extreme, Arc B390, 메모리 24GB), Windows 11
#  설치 내용:
#    - LM Studio + gpt-oss-20b (대화/코딩) + Gemma 4 E4B (사진 이해)
#    - AI Playground (Intel) + FLUX.2 Klein 4B (그림 생성)
#    - Open WebUI (ChatGPT 같은 채팅 화면) + 바탕화면 "덜누름 로컬 AI" 아이콘
#  같은 파일을 다시 실행해도 안전합니다. 이미 설치된 것은 건너뜁니다.
# ============================================================
param(
  [switch]$SkipChecks   # 사양 확인 건너뛰기 (고급)
)

# 'Continue': uv/curl 등이 진행 상황을 오류 출력으로 내보내도 멈추지 않게. 실패 여부는 각 단계에서 직접 확인합니다.
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Base = "$env:USERPROFILE\LocalAI"
$Dl = "$Base\downloads"
New-Item -ItemType Directory -Force $Base, "$Base\logs", $Dl | Out-Null
$log = "$Base\logs\install-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
Start-Transcript -Path $log | Out-Null

$script:StepNo = 0
$TotalSteps = 10
function Step([string]$msg) { $script:StepNo++; Write-Host ""; Write-Host "[$script:StepNo/$TotalSteps] $msg" -ForegroundColor Cyan }
function Ok([string]$msg)   { Write-Host "   OK  $msg" -ForegroundColor Green }
function Info([string]$msg) { Write-Host "   ..  $msg" }
function Warn([string]$msg) { Write-Host "   !!  $msg" -ForegroundColor Yellow }
function Fail([string]$msg) {
  Write-Host ""; Write-Host "설치를 멈췄어요: $msg" -ForegroundColor Red
  Write-Host "기록 파일: $log" -ForegroundColor Yellow
  Stop-Transcript | Out-Null; Read-Host "Enter를 누르면 닫혀요"; exit 1
}

# ---------- 파일 받기 + 검증 (이어받기, 멈춤 감지, SHA256 확인) ----------
function Get-VerifiedFile {
  param([string]$Url, [string]$Dest, [int64]$Size, [string]$Sha256 = '')
  $name = Split-Path $Dest -Leaf
  New-Item -ItemType Directory -Force (Split-Path $Dest) | Out-Null

  $check = {
    param($p)
    if (-not (Test-Path $p)) { return $false }
    if ((Get-Item $p).Length -ne $Size) { return $false }
    if ($Sha256) { return ((Get-FileHash $p -Algorithm SHA256).Hash.ToLower() -eq $Sha256) }
    return $true
  }

  if (Test-Path $Dest) {
    Info "$name 확인 중..."
    if (& $check $Dest) { Ok "$name (이미 있음, 검증 완료)"; return }
    Warn "$name 이 손상돼 있어 다시 받아요"; Remove-Item $Dest -Force
  }

  # USB 등에 함께 넣어 둔 models 폴더에 같은 파일이 있으면 복사 (인터넷 절약)
  if ($Sha256 -and (Test-Path "$Here\models")) {
    $local = Get-ChildItem "$Here\models" -Recurse -File -Filter $name -ErrorAction SilentlyContinue | Where-Object { $_.Length -eq $Size } | Select-Object -First 1
    if ($local) {
      Info "$name 을 설치 폴더의 models 에서 복사 중... ($([math]::Round($Size/1GB,2)) GB)"
      Copy-Item $local.FullName $Dest -Force
      if (& $check $Dest) { Ok "$name (복사, 검증 완료)"; return }
      Warn "복사한 $name 이 맞지 않아 인터넷에서 받을게요"; Remove-Item $Dest -Force
    }
  }

  $tmp = "$Dest.part"
  Info "$name 받는 중... ($([math]::Round($Size/1GB,2)) GB)"
  for ($t = 1; $t -le 40; $t++) {
    & curl.exe -L -sS --retry 5 --retry-delay 3 --speed-limit 100000 --speed-time 30 -C - -o $tmp $Url
    if ((Test-Path $tmp) -and (Get-Item $tmp).Length -ge $Size) { break }
    $got = if (Test-Path $tmp) { (Get-Item $tmp).Length } else { 0 }
    Info ("  이어받기 {0}회째 ({1:N1} / {2:N1} GB)" -f $t, ($got/1GB), ($Size/1GB))
    Start-Sleep 3
  }
  if (-not (& $check $tmp)) { Remove-Item $tmp -Force -ErrorAction SilentlyContinue; Fail "$name 다운로드/검증 실패. 인터넷 연결을 확인하고 다시 실행해 주세요." }
  Move-Item $tmp $Dest -Force
  Ok "$name (다운로드, 검증 완료)"
}

function Find-Uv {
  $c = Get-Command uv -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  $p = Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Directory -Filter 'astral-sh.uv*' -ErrorAction SilentlyContinue |
       ForEach-Object { Join-Path $_.FullName 'uv.exe' } | Where-Object { Test-Path $_ } | Select-Object -First 1
  if ($p) { return $p }
  $l = "$env:LOCALAPPDATA\Microsoft\WinGet\Links\uv.exe"; if (Test-Path $l) { return $l }
  return $null
}

Write-Host "==============================================" -ForegroundColor White
Write-Host "   덜누름 로컬 AI 설치를 시작합니다" -ForegroundColor White
Write-Host "   (모델 다운로드 약 30GB, 전체 30분~1시간)" -ForegroundColor White
Write-Host "==============================================" -ForegroundColor White

# ============================================================
Step "PC 사양 확인"
# ============================================================
$ramGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB, 1)
$gpus = (Get-CimInstance Win32_VideoController | ForEach-Object Name) -join ', '
$freeGB = [math]::Round((Get-PSDrive C).Free/1GB)
Info "메모리 $ramGB GB / GPU: $gpus / C 드라이브 남은 공간 $freeGB GB"
if (-not $SkipChecks) {
  if ($freeGB -lt 70) { Fail "C 드라이브 남은 공간이 70GB 이상 필요해요 (현재 $freeGB GB)." }
  if ($ramGB -lt 15) { Fail "메모리가 16GB 이상 필요해요 (현재 $ramGB GB)." }
  if ($gpus -notmatch 'Arc') { Warn "Intel Arc GPU가 보이지 않아요. 대화는 되지만 그림 생성은 느리거나 안 될 수 있어요." }
}
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Fail "winget(앱 설치 관리자)이 없어요. Microsoft Store에서 '앱 설치 관리자'를 설치/업데이트한 뒤 다시 실행해 주세요." }
if (-not (Get-Command curl.exe -ErrorAction SilentlyContinue)) { Fail "curl.exe 를 찾을 수 없어요 (Windows 10 1803 이상 필요)." }
Ok "사양 확인 완료"

# ============================================================
Step "LM Studio 설치 (대화 모델 실행 프로그램)"
# ============================================================
$lmsApp = "$env:LOCALAPPDATA\Programs\LM Studio\LM Studio.exe"
if (Test-Path $lmsApp) { Ok "이미 설치돼 있어요" }
else {
  & winget install --id ElementLabs.LMStudio --exact --source winget --silent --accept-package-agreements --accept-source-agreements
  if (-not (Test-Path $lmsApp)) { Fail "LM Studio 설치에 실패했어요." }
  Ok "설치 완료"
}
$lms = "$env:USERPROFILE\.lmstudio\bin\lms.exe"
if (-not (Test-Path $lms)) {
  Info "LM Studio를 처음 한 번 실행해서 준비하는 중... (창이 뜨면 그대로 두세요)"
  Start-Process $lmsApp
  for ($i = 0; $i -lt 90 -and -not (Test-Path $lms); $i++) { Start-Sleep 2 }
  if (-not (Test-Path $lms)) { Fail "LM Studio 초기 준비(lms)가 끝나지 않았어요. LM Studio를 한 번 직접 열었다 닫은 뒤 다시 실행해 주세요." }
}
Ok "LM Studio 준비 완료"

# ============================================================
Step "대화 모델 받기 (gpt-oss-20b 12.1GB, Gemma 4 E4B 7.2GB)"
# ============================================================
$hf = "https://huggingface.co"
$mdl = "$env:USERPROFILE\.lmstudio\models\local"
Get-VerifiedFile "$hf/lmstudio-community/gpt-oss-20b-GGUF/resolve/main/gpt-oss-20b-MXFP4.gguf" `
  "$mdl\gpt-oss-20b-GGUF\gpt-oss-20b-MXFP4.gguf" 12109565632 '65d06d31a3977d553cb3af137b5c26b5f1e9297a6aaa29ae7caa98788cde53ab'
Get-VerifiedFile "$hf/lmstudio-community/gemma-4-E4B-it-GGUF/resolve/main/gemma-4-E4B-it-Q6_K.gguf" `
  "$mdl\gemma-4-E4B-it-GGUF\gemma-4-E4B-it-Q6_K.gguf" 6217260864 '17f0e51b02f755f85c5e5c865dd44f86306cccaa2acfa2ef4a90456acf526c54'
Get-VerifiedFile "$hf/lmstudio-community/gemma-4-E4B-it-GGUF/resolve/main/mmproj-gemma-4-E4B-it-BF16.gguf" `
  "$mdl\gemma-4-E4B-it-GGUF\mmproj-gemma-4-E4B-it-BF16.gguf" 991551840 'bdfc4935857658dfdc8d1adebfa3897c2fec8b3323410f4f73ade36d6efa02be'

# 모델별 기본 설정: 기억 용량(컨텍스트)과 동시 요청 수
$cfgDir = "$env:USERPROFILE\.lmstudio\.internal\user-concrete-model-default-config\local"
function Write-ModelDefault([string]$rel, [int]$ctx, [int]$par) {
  $p = Join-Path $cfgDir $rel
  New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null
  $j = @{ preset = ''; operation = @{ fields = @() }; load = @{ fields = @(
        @{ key = 'llm.load.contextLength'; value = $ctx },
        @{ key = 'llm.load.numParallelSessions'; value = $par }) } } | ConvertTo-Json -Depth 6
  [IO.File]::WriteAllText($p, $j, (New-Object Text.UTF8Encoding $false))
}
Write-ModelDefault 'gpt-oss-20b-GGUF\gpt-oss-20b-MXFP4.gguf.json' 32768 2
Write-ModelDefault 'gemma-4-E4B-it-GGUF\gemma-4-E4B-it-Q6_K.gguf.json' 16384 2
Ok "모델 기본 설정 (gpt-oss 32K, Gemma 16K) 적용"

# ============================================================
Step "AI Playground 설치 (Intel 공식, 그림 엔진 포함)"
# ============================================================
$aipgDir = "$env:LOCALAPPDATA\Programs\AI Playground"
$aipgExe = "$aipgDir\AI Playground.exe"
if (Test-Path $aipgExe) { Ok "이미 설치돼 있어요" }
else {
  $inst = "$Dl\AI-Playground-installer.exe"
  $aipgUrl = "https://github.com/intel/AI-Playground/releases/download/v3.3.0-beta-rc2/AI-Playground-installer.exe"
  Info "설치 파일 받는 중... (약 260MB)"
  & curl.exe -L -sS --retry 5 -o $inst $aipgUrl
  $sig = Get-AuthenticodeSignature $inst
  if ($sig.Status -ne 'Valid' -or $sig.SignerCertificate.Subject -notmatch 'O=Intel Corporation') { Fail "AI Playground 설치 파일의 Intel 서명을 확인하지 못했어요." }
  Ok "Intel 서명 확인"
  Start-Process $inst -ArgumentList '/S' -Wait
  if (-not (Test-Path $aipgExe)) { Fail "AI Playground 설치에 실패했어요." }
  Ok "설치 완료"
}

# 그림 엔진(ComfyUI) 구성요소는 AI Playground 첫 실행 화면에서 설치해야 해요.
$comfyDir = "$aipgDir\resources\ComfyUI"
$comfyPy = "$comfyDir\.venv\Scripts\python.exe"
function Test-ComfyReady {
  if (-not (Test-Path $comfyPy)) { return $false }
  $o = & $comfyPy -c "import torch,sys; sys.stdout.write(str(torch.xpu.is_available()))" 2>$null
  return ($LASTEXITCODE -eq 0 -and "$o" -eq 'True')
}
if (Test-ComfyReady) { Ok "그림 엔진 구성요소 준비돼 있어요 (Intel GPU 인식)" }
else {
  Start-Process $aipgExe
  Write-Host ""
  Write-Host "   ★ 지금 열린 AI Playground 창에서 [Install] 버튼을 눌러 주세요." -ForegroundColor Magenta
  Write-Host "     (구성요소 설치 10~30분. 약관 화면이 나오면 확인 후 동의해 주세요.)" -ForegroundColor Magenta
  Write-Host "     설치가 끝나면 이 창이 자동으로 다음 단계로 넘어가요." -ForegroundColor Magenta
  $sw = [Diagnostics.Stopwatch]::StartNew()
  while (-not (Test-ComfyReady)) {
    if ($sw.Elapsed.TotalMinutes -gt 90) { Fail "90분이 지나도 그림 엔진 구성요소가 준비되지 않았어요. AI Playground에서 설치를 마친 뒤 이 설치 파일을 다시 실행해 주세요." }
    Start-Sleep 20
    Info ("  기다리는 중... {0:N0}분 경과" -f $sw.Elapsed.TotalMinutes)
  }
  Ok "그림 엔진 구성요소 준비 완료 (Intel GPU 인식)"
  Get-Process 'AI Playground' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep 3
  Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object { $_.ExecutablePath -like "$aipgDir*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

# ============================================================
Step "그림 모델 받기 (FLUX.2 Klein 4B, 약 8.6GB)"
# ============================================================
$cm = "$aipgDir\resources\models\ComfyUI"
Get-VerifiedFile "$hf/black-forest-labs/FLUX.2-klein-4b-fp8/resolve/main/flux-2-klein-4b-fp8.safetensors" `
  "$cm\unet\black-forest-labs---FLUX.2-klein-4b-fp8\flux-2-klein-4b-fp8.safetensors" 4070624520 '97ed34fe0567e436200f2faee3939b88f2b5d99f8af2a4dc16532c4245c0ccb6'
Get-VerifiedFile "$hf/Comfy-Org/vae-text-encorder-for-flux-klein-4b/resolve/main/split_files/text_encoders/qwen_3_4b_fp4_flux2.safetensors" `
  "$cm\clip\Comfy-Org---vae-text-encorder-for-flux-klein-4b\split_files\text_encoders\qwen_3_4b_fp4_flux2.safetensors" 3848213998 '3eab03a77adb0ee5304a4e677d5c10ac22f9049c1d7c894adca4f8bb39206ca8'
Get-VerifiedFile "$hf/Comfy-Org/vae-text-encorder-for-flux-klein-4b/resolve/main/split_files/vae/flux2-vae.safetensors" `
  "$cm\vae\Comfy-Org---vae-text-encorder-for-flux-klein-4b\split_files\vae\flux2-vae.safetensors" 336211292 '868fe7b343cc8f3a19dbcfcafbc3d5f888802be3f89bd81b65b3621a066ce8f3'
# AI Playground 자체 "Pro Image" 메뉴에서도 쓰는 안전 필터 파일
Get-VerifiedFile "$hf/AdamCodd/vit-base-nsfw-detector/resolve/main/model.safetensors" `
  "$cm\nsfw_detector\vit-base-nsfw-detector\model.safetensors" 344391328 '266efb8bf67c1e865a577222fbbd6ddb149b9e00ba0d2b50466a034837f026a4'
Get-VerifiedFile "$hf/AdamCodd/vit-base-nsfw-detector/resolve/main/config.json" `
  "$cm\nsfw_detector\vit-base-nsfw-detector\config.json" 715
Get-VerifiedFile "$hf/AdamCodd/vit-base-nsfw-detector/resolve/main/preprocessor_config.json" `
  "$cm\nsfw_detector\vit-base-nsfw-detector\preprocessor_config.json" 232

# ============================================================
Step "파이썬 + 채팅 화면(Open WebUI 0.13.3) 설치"
# ============================================================
$uv = Find-Uv
if (-not $uv) {
  & winget install --id astral-sh.uv --exact --source winget --silent --accept-package-agreements --accept-source-agreements
  $uv = Find-Uv
  if (-not $uv) { Fail "uv(파이썬 설치 도구) 설치에 실패했어요." }
}
Ok "uv: $uv"
# 모든 파일을 LocalAI 폴더 안에 둡니다 (다른 앱 안에서 설치해도 바탕화면 아이콘에서 보이도록)
$env:UV_PYTHON_INSTALL_DIR = "$Base\python"
$env:UV_TOOL_DIR = "$Base\uv-tools"
$env:UV_TOOL_BIN_DIR = "$Base\bin"
$env:UV_CACHE_DIR = "$Base\uv-cache"
$owPy = "$Base\uv-tools\open-webui\Scripts\python.exe"
$ver = $null
if (Test-Path $owPy) { $ver = & $owPy -c "import importlib.metadata as m; print(m.version('open-webui'))" 2>$null }
if ("$ver".Trim() -eq '0.13.3' -and (Test-Path "$Base\bin\open-webui.exe")) { Ok "Open WebUI 0.13.3 이미 설치돼 있어요" }
else {
  & $uv python install 3.11
  $py = (& $uv python find 3.11 --managed-python 2>$null | Select-Object -First 1)
  if (-not $py -or -not (Test-Path $py)) { Fail "파이썬 3.11 설치에 실패했어요." }
  Info "Open WebUI 설치 중... (약 2GB, 5~10분)"
  & $uv tool install --force "open-webui==0.13.3" --python $py
  if (-not (Test-Path "$Base\bin\open-webui.exe")) { Fail "Open WebUI 설치에 실패했어요." }
  Ok "Open WebUI 설치 완료"
}
Info "첨부 문서 읽기용 모델 미리 받기 (오프라인 대비)..."
& $owPy -I -c "from huggingface_hub import snapshot_download; snapshot_download('sentence-transformers/all-MiniLM-L6-v2')" 2>$null | Out-Null
if ($LASTEXITCODE -eq 0) { Ok "문서 읽기용 모델 준비" } else { Warn "문서 읽기용 모델을 못 받았어요 (첫 실행 때 인터넷이 필요할 수 있어요)" }

# ============================================================
Step "실행 파일과 설정 복사"
# ============================================================
foreach ($f in 'start-chat.ps1', 'flux2-klein-workflow.json', 'flux2-klein-nodes.json') {
  Copy-Item "$Here\payload\$f" "$Base\$f" -Force
}
Ok "LocalAI 폴더에 복사 완료: $Base"

# ============================================================
Step "바탕화면 '덜누름 로컬 AI' 아이콘 만들기"
# ============================================================
$desk = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut("$desk\덜누름 로컬 AI.lnk")
$lnk.TargetPath = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
$lnk.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$Base\start-chat.ps1`""
$lnk.WorkingDirectory = $Base
if (Test-Path $lmsApp) { $lnk.IconLocation = "$lmsApp,0" }
$lnk.Description = "로컬 AI 채팅 (Open WebUI + LM Studio + FLUX)"
$lnk.Save()
Ok "아이콘 생성: $desk\덜누름 로컬 AI.lnk"

# ============================================================
Step "첫 실행 + 채팅 화면 설정 (2~3분)"
# ============================================================
# 이미 떠 있는 채팅 화면이 있으면 새 설정으로 다시 켜기
# 8080 포트를 쓰는 것이 우리 채팅 화면(LocalAI 폴더 안 프로그램)일 때만 끕니다. 다른 프로그램이면 멈추고 알려 줘요.
$c = Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($c) {
  $pp = Get-Process -Id $c.OwningProcess -ErrorAction SilentlyContinue
  if ($pp -and "$($pp.Path)" -like "$Base\*") { Stop-Process -Id $c.OwningProcess -Force -ErrorAction SilentlyContinue; Start-Sleep 3 }
  else { Fail "8080 포트를 다른 프로그램($($pp.ProcessName))이 쓰고 있어요. 그 프로그램을 끈 뒤 다시 실행해 주세요." }
}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$Base\start-chat.ps1" -NoBrowser
if ($LASTEXITCODE -ne 0) { Fail "채팅 화면 첫 실행에 실패했어요. 기록: $Base\logs\open-webui-error.log" }
Ok "채팅 화면 실행 확인"

# 모델별 기본값: '이미지' 스위치 켜기 + 그림 요청 시 그림 도구 사용 지시
$api = "http://127.0.0.1:8080"
try { $tok = (Invoke-RestMethod "$api/api/v1/auths/signin" -Method Post -ContentType 'application/json' -Body '{"email":"","password":""}' -ErrorAction Stop).token }
catch { Fail "채팅 화면 설정용 로그인에 실패했어요: $($_.Exception.Message)" }
$H = @{ Authorization = "Bearer $tok" }
$sys = "You are a helpful assistant running locally on the user's PC. Reply in the user's language (Korean if they write Korean). You CAN create real images: whenever the user asks you to draw, paint, illustrate, or create/make an image, picture, photo or 그림/이미지/사진 (e.g. '그려줘', '그림 만들어줘', '이미지 생성'), you MUST call the generate_image tool with a detailed English prompt. Never answer with ASCII art and never say you cannot draw. For normal questions, just answer in text without calling the tool."
$defs = @(
  @{ id = 'gpt-oss-20b';    desc = '대화·코딩·추론 (그림 그리기 가능)'; vision = $false },
  @{ id = 'gemma-4-e4b-it'; desc = '사진 이해 + 빠른 그림 그리기';       vision = $true }
)
foreach ($d in $defs) {
  $body = @{
    id = $d.id; base_model_id = $null; name = $d.id; is_active = $true
    meta = @{ description = $d.desc; defaultFeatureIds = @('image_generation')
              capabilities = @{ image_generation = $true; vision = $d.vision; builtin_tools = $true; file_upload = $true; citations = $true } }
    params = @{ function_calling = 'native'; system = $sys }
  } | ConvertTo-Json -Depth 8
  $bytes = [Text.Encoding]::UTF8.GetBytes($body)
  $exists = $false
  try { Invoke-RestMethod "$api/api/v1/models/model?id=$($d.id)" -Headers $H -ErrorAction Stop | Out-Null; $exists = $true } catch {}
  try {
    if ($exists) { Invoke-RestMethod "$api/api/v1/models/model/update?id=$($d.id)" -Method Post -Headers $H -ContentType 'application/json; charset=utf-8' -Body $bytes -ErrorAction Stop | Out-Null }
    else         { Invoke-RestMethod "$api/api/v1/models/create" -Method Post -Headers $H -ContentType 'application/json; charset=utf-8' -Body $bytes -ErrorAction Stop | Out-Null }
    Ok "$($d.id): 이미지 스위치 기본 켜짐 + 그림 도구 지시 적용"
  } catch { Warn "$($d.id) 설정 실패: $($_.Exception.Message) (채팅은 되지만 '이미지' 스위치를 직접 켜야 할 수 있어요)" }
}

# ============================================================
Step "설치 완료"
# ============================================================
Write-Host ""
Write-Host "==============================================" -ForegroundColor Green
Write-Host "  설치가 끝났어요!" -ForegroundColor Green
Write-Host "  앞으로는 바탕화면의 [덜누름 로컬 AI] 아이콘만 누르면 돼요." -ForegroundColor Green
Write-Host "  - 대화/코딩: gpt-oss-20b   - 사진 이해/빠른 그림: gemma-4-e4b-it" -ForegroundColor Green
Write-Host "  - '고양이 그려줘' 처럼 쓰면 그림도 그려줘요" -ForegroundColor Green
Write-Host "==============================================" -ForegroundColor Green
Write-Host "기록 파일: $log"
Stop-Transcript | Out-Null
Start-Process "http://127.0.0.1:8080"
Read-Host "Enter를 누르면 이 창이 닫혀요"
