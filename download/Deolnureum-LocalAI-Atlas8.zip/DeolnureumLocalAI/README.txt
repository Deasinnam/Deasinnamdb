﻿덜누름 로컬 AI 설치 파일 (에이서 프레데터 아틀라스 8 최적화)
========================================================

인터넷 없이 내 PC에서 돌아가는 AI 세트입니다.
- 채팅 화면: Open WebUI (ChatGPT와 비슷한 화면, 브라우저에서 열림)
- 대화/코딩: gpt-oss-20b (OpenAI 공개 모델)
- 사진 이해 + 빠른 대화: Gemma 4 E4B (Google 공개 모델)
- 그림 그리기: FLUX.2 Klein 4B (Black Forest Labs), Intel AI Playground의 그림 엔진(ComfyUI)으로 실행

권장 사양
- 에이서 프레데터 아틀라스 8 (Intel Arc G3 Extreme, Arc B390 내장 GPU, 메모리 24GB), Windows 11
- 다른 기기는 시험하지 않았어요. Intel Arc GPU가 없으면 그림 생성이 동작하지 않아요.
- C 드라이브 남은 공간 70GB 이상
- 설치할 때만 인터넷 필요 (약 30GB 다운로드, 30분~1시간)

설치 방법
1. 이 폴더 전체를 대상 PC에 복사합니다 (압축 파일이면 먼저 압축 풀기).
2. [설치하기.cmd]를 더블클릭합니다.
   - "Windows의 PC 보호" 창이 뜨면 [추가 정보] -> [실행]을 누르세요.
3. 중간에 AI Playground 창이 뜨면 [Install] 버튼을 눌러 주세요.
   (그림 엔진 구성요소 설치, 10~30분. 끝나면 설치 창이 알아서 다음 단계로 넘어가요.)
4. "설치가 끝났어요!"가 나오면 완료입니다.

사용 방법
- 바탕화면 [덜누름 로컬 AI] 아이콘 더블클릭 -> 약 40초 뒤 브라우저에 채팅 화면이 열려요.
- 입력창 오른쪽 아래에서 모델 선택 (gpt-oss-20b / gemma-4-e4b-it)
- "고양이 그려줘"처럼 쓰면 그림을 그려요. 그림 장면은 Gemma가 더 빨라요 (약 1분).
- 사진 분석은 Gemma를 고르고 [+] -> 파일 업로드로 사진을 넣으세요.

인터넷 아끼기 (선택)
- 이미 설치된 PC에서 아래 파일들을 이 폴더의 [models] 폴더에 넣어 두면 다운로드 대신 복사해요.
  (파일 이름만 맞으면 하위 폴더 구조는 상관없어요. 받은 뒤 SHA256으로 검사합니다.)
  gpt-oss-20b-MXFP4.gguf, gemma-4-E4B-it-Q6_K.gguf, mmproj-gemma-4-E4B-it-BF16.gguf,
  flux-2-klein-4b-fp8.safetensors, qwen_3_4b_fp4_flux2.safetensors, flux2-vae.safetensors,
  model.safetensors (nsfw 필터)
  위치(원본 PC): C:\Users\<사용자>\.lmstudio\models\local\...
                 C:\Users\<사용자>\AppData\Local\Programs\AI Playground\resources\models\ComfyUI\...

설치되는 위치
- C:\Users\<사용자>\LocalAI          실행 스크립트, 채팅 데이터, 생성 그림(images), 기록(logs)
- C:\Users\<사용자>\.lmstudio        LM Studio 모델
- C:\Users\<사용자>\AppData\Local\Programs\LM Studio, AI Playground

문제가 생기면
- 설치 기록: C:\Users\<사용자>\LocalAI\logs\install-*.log
- 채팅 화면 오류: C:\Users\<사용자>\LocalAI\logs\open-webui-error.log
- 다른 프로그램이 8080 포트를 쓰고 있으면 설치가 멈춰요. 그 프로그램을 끄고 다시 실행하세요.
- 설치 파일은 다시 실행해도 안전해요. 이미 된 단계는 건너뜁니다.
- AI Playground와 덜누름 로컬 AI를 동시에 켜면 메모리가 부족해요. 하나씩 쓰세요.
