﻿# 로컬 AI 채팅 시작 스크립트
# LM Studio 서버(대화 모델) + ComfyUI(그림 엔진) + Open WebUI(채팅 화면)를 켜고 브라우저를 엽니다.
param([switch]$NoBrowser)

$ErrorActionPreference = 'Continue'
$lms = "$env:USERPROFILE\.lmstudio\bin\lms.exe"
$webui = "$env:USERPROFILE\LocalAI\bin\open-webui.exe"
$url = "http://127.0.0.1:8080"
$base = "$env:USERPROFILE\LocalAI"
$comfyDir = "$env:LOCALAPPDATA\Programs\AI Playground\resources\ComfyUI"
$comfyPy = "$comfyDir\.venv\Scripts\python.exe"
$comfyUrl = "http://127.0.0.1:8188"

# 그림 엔진(ComfyUI)과 채팅 화면이 같이 쓰는 PC 내부용 비밀번호 (처음 한 번 만들어 저장)
$tokenFile = "$base\comfy-token.txt"
if (-not (Test-Path $tokenFile)) {
  $t = -join ((1..48) | ForEach-Object { '{0:x}' -f (Get-Random -Maximum 16) })
  [IO.File]::WriteAllText($tokenFile, $t)
}
$comfyToken = ([IO.File]::ReadAllText($tokenFile)).Trim()

Write-Host "0/3 그림 엔진(ComfyUI) 시작..." -ForegroundColor Cyan
$comfyRunning = $false
try { Invoke-WebRequest "$comfyUrl/queue" -UseBasicParsing -TimeoutSec 2 | Out-Null; $comfyRunning = $true } catch {}
if (-not $comfyRunning -and (Test-Path $comfyPy)) {
  New-Item -ItemType Directory -Force "$base\images" | Out-Null
  $env:AIPG_LOOPBACK_TOKEN = $comfyToken
  Start-Process -FilePath $comfyPy -WorkingDirectory $comfyDir -WindowStyle Minimized -ArgumentList @(
    "main.py", "--port", "8188", "--listen", "127.0.0.1",
    "--output-directory", "`"$base\images`"",
    "--extra-model-paths-config", "`"$comfyDir\extra_model_paths.yaml`"",
    "--disable-auto-launch")
}

Write-Host "1/3 LM Studio 서버 시작..." -ForegroundColor Cyan
& $lms server start | Out-Null
# LM Studio가 모델 목록을 준비할 때까지 기다립니다 (재부팅 직후 대비)
for ($i = 0; $i -lt 60; $i++) {
  try { $m = Invoke-RestMethod "http://127.0.0.1:1234/v1/models" -TimeoutSec 3; if ($m.data.Count -gt 0) { break } } catch {}
  Start-Sleep 2
}

# 이미 채팅 화면이 켜져 있으면 브라우저만 엽니다.
$running = $false
try { Invoke-WebRequest "$url/health" -UseBasicParsing -TimeoutSec 2 | Out-Null; $running = $true } catch {}

if (-not $running) {
  Write-Host "2/3 채팅 화면(Open WebUI) 시작... (보통 40초, 설치 직후 첫 실행은 2~3분)" -ForegroundColor Cyan
  $env:DATA_DIR = "$base\open-webui-data"
  $env:WEBUI_NAME = "덜누름 로컬 AI"
  $env:WEBUI_AUTH = "False"
  $env:DEFAULT_LOCALE = "ko-KR"
  $env:ENABLE_OLLAMA_API = "False"
  $env:OPENAI_API_BASE_URL = "http://127.0.0.1:1234/v1"
  $env:OPENAI_API_KEY = "lm-studio"
  $env:ENABLE_VERSION_UPDATE_CHECK = "False"
  # 아래 설정을 항상 이 파일 기준으로 적용 (화면에서 바꾼 값보다 우선)
  $env:ENABLE_PERSISTENT_CONFIG = "False"
  # 그림 생성 연결 (FLUX.2 Klein 4B)
  $env:ENABLE_IMAGE_GENERATION = "True"
  $env:IMAGE_GENERATION_ENGINE = "comfyui"
  $env:COMFYUI_BASE_URL = $comfyUrl
  $env:COMFYUI_API_KEY = $comfyToken
  $env:COMFYUI_WORKFLOW = [IO.File]::ReadAllText("$base\flux2-klein-workflow.json")
  $env:COMFYUI_WORKFLOW_NODES = [IO.File]::ReadAllText("$base\flux2-klein-nodes.json")
  $env:IMAGE_GENERATION_MODEL = "black-forest-labs---FLUX.2-klein-4b-fp8\flux-2-klein-4b-fp8.safetensors"
  $env:IMAGE_SIZE = "1024x1024"
  $env:IMAGE_STEPS = "4"
  $env:ENABLE_IMAGE_PROMPT_GENERATION = "True"
  if (Test-Path "$base\open-webui-data\.offline-ready") { $env:OFFLINE_MODE = "True"; $env:HF_HUB_OFFLINE = "1" }
  $env:PYTHONIOENCODING = "utf-8"
  New-Item -ItemType Directory -Force "$base\logs" | Out-Null
  Start-Process -FilePath $webui -ArgumentList "serve","--host","127.0.0.1","--port","8080" -WorkingDirectory $base -WindowStyle Hidden `
    -RedirectStandardOutput "$base\logs\open-webui.log" -RedirectStandardError "$base\logs\open-webui-error.log"

  for ($i = 0; $i -lt 150; $i++) {
    try { Invoke-WebRequest "$url/health" -UseBasicParsing -TimeoutSec 2 | Out-Null; $running = $true; break } catch { Start-Sleep 2 }
  }
}

if ($running) {
  New-Item -ItemType File -Force "$base\open-webui-data\.offline-ready" | Out-Null
  if (-not $NoBrowser) {
    Write-Host "3/3 브라우저 열기: $url" -ForegroundColor Green
    Start-Process $url
  }
  exit 0
} else {
  Write-Host "채팅 화면이 시작되지 않았어요." -ForegroundColor Red
  Write-Host "오류 기록: $base\logs\open-webui-error.log" -ForegroundColor Yellow
  if (Test-Path "$base\logs\open-webui-error.log") { Get-Content "$base\logs\open-webui-error.log" -Tail 15 }
  if (-not $NoBrowser) { Read-Host "Enter를 누르면 닫혀요" }
  exit 1
}
